﻿namespace TeamKville.Shared.Dto;

public class ProductQuantityDto
{
	public ProductDto ProductDto { get; set; }
	public int Quantity { get; set; }

}