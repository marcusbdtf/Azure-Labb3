﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamKville.Shared.Models
{
	public class AddressModel
	{
		public string City { get; set; }
		public string Street { get; set; }
		public string PostNumber { get; set; }
	}
}
